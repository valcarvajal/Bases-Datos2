CREATE TABLE prueba(
    id INT PRIMARY KEY
);